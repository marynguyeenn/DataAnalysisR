library(devtools)
library(roxygen2)

setwd("..")
setwd("Assignment2")

install("Assignment2Package")

update_DD_date(testing, testing$Longitude, testing$Latitude, testing$Date)

setwd("..")
testing <- read.csv("gw_data_A2.csv")

use_data(testing)

update_DD_date(testing, testing$Longitude, testing$Latitude, testing$Date)
